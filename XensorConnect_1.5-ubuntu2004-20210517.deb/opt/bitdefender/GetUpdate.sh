#!/bin/bash

cd /opt/bitdefender
# redirect stderr(2) to null:
exec 2>/dev/null
UPDSAMPLE="./RunUpdate/updateSample"
if [[ -e  $UPDSAMPLE ]]; then 
	export LD_LIBRARY_PATH=./RunUpdate/.
	if [[ -n $1 ]]; then 
		 ###$UPDSAMPLE -lp "$PWD" -proxy 127.0.0.1:8080 -fl $1/av32bit
		 ##$UPDSAMPLE -lp "$PWD/Plugins32" -fl $1/av32bit
		 #$UPDSAMPLE -usePatches 1 -lp "$PWD" -proxy 127.0.0.1:8080 -fl $1/av32bit
                 $UPDSAMPLE -usePatches 1 -lp "$PWD/Plugins32" -fl $1/av32bit
	else
		echo "Warning! First parameter for the batch should be the URL in the format : http://hostname.tld"
	fi
else 	
	echo "The updateSample file does not exist."
fi
if [[ -e  $UPDSAMPLE ]]; then 
	export LD_LIBRARY_PATH=./RunUpdate/.
	if [[ -n $1 ]]; then 
		 ###$UPDSAMPLE -lp "$PWD" -proxy 127.0.0.1:8080 -fl $1/av32bit
		 ##$UPDSAMPLE -lp "$PWD/Plugins64" -fl $1/av64bit
		 #$UPDSAMPLE -usePatches 1 -lp "$PWD" -proxy 127.0.0.1:8080 -fl $1/av32bit
		 $UPDSAMPLE -usePatches 1 -lp "$PWD/Plugins64" -fl $1/av64bit
	else
		echo "Warning! First parameter for the batch should be the URL in the format : http://hostname.tld"
	fi
else 	
	echo "The updateSample file does not exist."
fi




